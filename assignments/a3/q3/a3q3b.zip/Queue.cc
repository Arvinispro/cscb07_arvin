#include "Queue.h"
#include "QueueIterator.h"
#include "DigitalMedia.h"

Queue::Queue(): front{nullptr}, back{nullptr}, totalSecond{0}, secondsPlayed{0} {}
Queue::~Queue(){
  if(front != nullptr) delete front->next;
}           // the media items themselves are owned by the Library

void Queue::playNext( DigitalMedia * m ){
  Node *newmedia = new Node{m, this->front};
  this->totalSecond += m->getDuration();
  this->front = newmedia;
  if(this->back==nullptr) this->back = newmedia;
}  // adds m to the front of the queue
void Queue::playLast( DigitalMedia * m ){
  Node *newmedia = new Node{m, nullptr};
  this->totalSecond += m->getDuration();

  if(this->back == nullptr) this->back = newmedia;
  else {
    this->back->next = newmedia;
    this->back = newmedia;
  }
  if(this->front==nullptr) this->front = newmedia;

}  // adds m to the back of the queue

// "Plays" the item at the front of the queue: removes it from the queue, adds its
// duration to the number of seconds played, and returns it. Returns nullptr (and
// changes nothing) if the queue is empty.
DigitalMedia * Queue::play(){
  if(this->front==nullptr) return nullptr;
  Node played = *this->front;

  delete this->front;
  this->front = played.next;
  if(this->front == nullptr) this ->back = nullptr; //only 1 element
  
  this->secondsPlayed += played.m->getDuration();
  this -> totalSecond -= played.m->getDuration();
  return played.m;
}

// Removes every occurrence of m from the queue. Does nothing if m isn't in the queue.
void Queue::remove( DigitalMedia * m ){
  if(this->front == nullptr) return;
  
  Node *last = nullptr;
  Node *p = this->front;
  
  while(true){
    if(front == back){
      if(p->m == m){
        delete this->front;
        this -> front = nullptr;
        this -> back = nullptr;
        this->totalSecond = 0;
      }
      return;
    }
    else{
      if(p==front){//looking at front
        if(p->m==m){
          this->totalSecond -= p->m->getDuration();
          p = p->next;
          delete front;
          front = p;
          continue;
        }
        else{
          last = p;
          p = p->next;
          continue;
        }
      }
      if(p==back){
        if(p->m==m){
          this->totalSecond -= p->m->getDuration();
          delete back;
          last->next = nullptr;
          back = last;
        }
        return;
      }
      else{
        if(p->m==m){
          this->totalSecond -= p->m->getDuration();
          last ->next = p->next;
          delete p;
          p = last->next;
        }
        else{
          last = p;
          p = p->next;
          continue;
        }
      }

    }
  }
}

void Queue::reset(){
  this->secondsPlayed = 0;
}                       // resets the number of seconds played back to 0
int Queue::getTotalSeconds() const{
  return this->totalSecond;
}        // total duration of the items in the queue
int Queue::getSecondsPlayed() const{
  return this->secondsPlayed;
}       // total duration of the items played so far

QueueIterator Queue::begin() const{
  return QueueIterator{this->front, 0};
}        // Iterator set to the front of the queue.
QueueIterator Queue::end() const{
  return QueueIterator{nullptr, 0};
}  

// Returns modified output stream. Outputs each item on its own line, in queue order, as
// a tab, the position of the item (width 3, padded with '0'), ": ", the item's information,
// and " starts in N seconds" where N is the iterator's elapsed time at that item. The last
// line is "Total: N seconds", N being the total duration of the items in the queue.
std::ostream & operator<<( std::ostream & out, const Queue & q ){
  int p1=0, p10=0, p100=0;

  for(QueueIterator p=q.begin(); p != q.end(); p=++p){
    out << "\t" << p100 << p10 << p1 << ": ";
    (*p) -> print(out);
    out << " starts in " << p.getElapsedTime() << " seconds" << std::endl;
    ++p1;
    if(p1 == 10){
      ++p10;
      p1=0;
    }
    if(p10 == 10){
      ++p100;
      p10=0;
    }
  }
  out << "Total: " << q.getTotalSeconds() << " seconds" << std::endl;
  return out;
}